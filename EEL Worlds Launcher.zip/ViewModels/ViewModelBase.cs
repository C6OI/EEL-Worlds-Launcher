﻿using ReactiveUI;

namespace EEL_Worlds_Launcher.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
